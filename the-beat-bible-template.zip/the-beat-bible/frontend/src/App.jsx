// Aquí irá la interfaz de usuario React
